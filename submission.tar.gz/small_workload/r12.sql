CREATE TABLE r12 (c0 bigint,c1 bigint,c2 bigint,c3 bigint,c4 bigint);
copy r12 from 'r12.tbl' delimiter '|';
