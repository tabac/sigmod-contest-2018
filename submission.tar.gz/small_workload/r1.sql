CREATE TABLE r1 (c0 bigint,c1 bigint,c2 bigint);
copy r1 from 'r1.tbl' delimiter '|';
