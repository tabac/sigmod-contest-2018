CREATE TABLE r5 (c0 bigint,c1 bigint,c2 bigint,c3 bigint);
copy r5 from 'r5.tbl' delimiter '|';
